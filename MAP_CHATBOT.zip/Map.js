import React, { useState }  from 'react'
import map from "./pics/petmap.jpg"
import Modal from "./components/Modal"
import head from "./pics/header.JPG"
import foot from  "./pics/bottom.JPG"

const Map = (props) => {
    let [modal, setModal] = useState(false)
  return (

    <div
      style={{
        width: '100%',
        minHeight: '100vh',
        overflow: 'auto',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
      }}
    >
            <header>
        <img src={head} 
        style={{
          width : '26.7%',
          position: 'fixed',
          top : '0px',
          left : '0px',
          zIndex : 1
        }}/>
      </header>
      <div
        style={{
          width: '390px',
          height: '844px',
          display: 'flex',
          alignItems: 'flex-start',
          flexShrink: 1,
          position: 'relative',
        }}
      >
        <div
          style={{
            backgroundColor: 'rgba(255, 255, 255, 1)',
            width: '390px',
            height: '844px',
            display: 'flex',
            alignItems: 'flex-start',
            flexShrink: '0',
            position: 'absolute',
            top: '0px',
            left: '0px',
            overflow: 'hidden',
          }}
        >
          <div
            style={{
              width: '395px',
              height: '562px',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'flex-start',
              flexShrink: '0',
              position: 'absolute',
              top: '100px',
              left: '-2px',
            }}
          >
            <img src={map} 
                style={{
                    borderRadius : '8px',
                    position :'fixed',
                    left : 10,
                    top : 70,
                    height : '90%',
                    width : '380px'

                }}
                onClick={()=>{
                    setModal(!modal);
                }}
                /
            >
        {
            modal ? <Modal /> : <div />
        }
          </div>

          </div>
      <footer>
        <img src={foot} 
        style={{
          width : '27%',
          position: 'fixed',
          bottom : '-5px',
          left : '-5px'
        }}/>
        </footer>
    </div>
    </div>

  )
}

export default Map
